-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 03, 2023 at 04:05 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `projectfilm_rpl3`
--

-- --------------------------------------------------------

--
-- Table structure for table `produk`
--

CREATE TABLE `produk` (
  `id` int(11) NOT NULL,
  `nama_barang` varchar(250) NOT NULL,
  `qty` int(11) NOT NULL,
  `harga` int(11) NOT NULL,
  `photo` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `produk`
--

INSERT INTO `produk` (`id`, `nama_barang`, `qty`, `harga`, `photo`) VALUES
(4, 'SMK Sakuci', 9, 1200, 'logo.png'),
(6, 'Meme 1CUK', 4, 25000, '211401f6790415222d65b5f9d2982243_t.jpg'),
(7, 'Apel', 5, 2000, 'OIP.jpg'),
(9, 'Skrinsut GTA', 90, 11000, 'gallery1.jpg'),
(10, 'Mutaharrr', 6, 50000, 'Screenshot (18).png');

-- --------------------------------------------------------

--
-- Table structure for table `ulasan`
--

CREATE TABLE `ulasan` (
  `id_ulasan` int(11) NOT NULL,
  `id_barang` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `ulasan` text NOT NULL,
  `rating` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ulasan`
--

INSERT INTO `ulasan` (`id_ulasan`, `id_barang`, `id_user`, `ulasan`, `rating`) VALUES
(1000000001, 6, 6, 'OOOMAMAMAMAAGAGAGAGAGGAGA', '10 Dari 10'),
(1000000002, 4, 7, 'Menurut saya SAKUCI itu akfjnlkasflal.ivaliv bvhnadibn;ajd;b ad.ibhloiadjb;a dbida;boahn dinbipadnipb.', '8 Dari 10');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(5) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `role` enum('admin','user') NOT NULL,
  `photo_user` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `nama`, `email`, `password`, `role`, `photo_user`) VALUES
(1, 'rudi', 'udin@gmail.com', '$2y$10$S7zejJbkWbzg/r6V0qDb0.M82Uol5z91K70YKzm045FFM3DLDadem', 'admin', ''),
(2, 'popo', 'popo@gmail.com', '$2y$10$cQpPu6nFAgVvxp07Hyt8sO/CM9qCxQeEy6X5Z8ufPv99RP3Jo3mHS', 'user', ''),
(3, 'ujang', 'ujang@gmail.com', '$2y$10$mrPcOH3bLQQ7SIEXVLogv.PtxvFFQRGWl9n6LygFxXQwa.viwPX5G', 'user', ''),
(4, 'kopi', 'k@gmail.com', '$2y$10$eRxHLDOOPvfsVAe70Hs3bOEgaB.V8X3Dpv9BqaGKfYGsnWAXUtINm', 'admin', ''),
(5, 'tutu', 'tit@gmail.com', '$2y$10$t1tN0zWn8WOdCGSpTDSWGunBLbV.7sdjIigVlFwA/hmb/UPj8NDNi', 'user', ''),
(6, 'asep', 'asepsunandar@gmail.com', '$2y$10$k2WhuCVjUyZPKZl/hgJZOeY5sODN0E0YD1Il0aFzLb8L7s.Bro6U2', 'user', ''),
(7, 'Yazzir', 'a@gmail.com', '$2y$10$xfDUlJCVPWRhn89RF8iL8.xNUh1mcIYfUvDiLM.0rU9gyGHwO4qwq', 'user', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `produk`
--
ALTER TABLE `produk`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ulasan`
--
ALTER TABLE `ulasan`
  ADD PRIMARY KEY (`id_ulasan`),
  ADD UNIQUE KEY `id_barang` (`id_barang`),
  ADD UNIQUE KEY `id_user` (`id_user`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `produk`
--
ALTER TABLE `produk`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `ulasan`
--
ALTER TABLE `ulasan`
  MODIFY `id_ulasan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1000000003;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `ulasan`
--
ALTER TABLE `ulasan`
  ADD CONSTRAINT `ulasan_ibfk_2` FOREIGN KEY (`id_barang`) REFERENCES `produk` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE,
  ADD CONSTRAINT `ulasan_ibfk_3` FOREIGN KEY (`id_user`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
